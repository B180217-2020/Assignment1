#/bin/bash

#preparation
git init
cp -r "/localdisk/data/BPSM/Assignment1/" .
mv Assignment1/* .
cd fastq/
gunzip *.fq.gz 

#question1: use fastqc to check the quality of the paired-end sequences
fastqc -o ./ -t 6 *.fq 
# -o output to current document -t 6 calculate the result in 6 lines
mv *.zip ..
cd ..
unzip '*.zip'

#question2: abstract the result of the quality of sequences from the output of fastqc, the result is saved into fastqcquality.txt
while read id stage name1 name2
	do echo "the fastqc output of $id $stage is" >> fastqcquality.txt
	echo ${name1:0:9} >> fastqcquality.txt
	cat ${name1//.fq.gz/_fastqc}/fastqc_data.txt | grep '>>Basic Statistics' >> fastqcquality.txt
	echo ${name2:0:9} >> fastqcquality.txt
	cat ${name2//.fq.gz/_fastqc}/fastqc_data.txt | grep '>>Basic Statistics' >> fastqcquality.txt
	done < fastq/fqfiles 
	#use the sample details to locate each filenames of the sequences
git add fastqcquality.txt
git commit -m "the process of the output of fastqc"
zip B180217-2020.Assignment1.zip fastqcquality.txt

#question3:use bowtie2 to align the read pairs to the genome, and use samtools to convert sam files to bam files
mv Tbb_genome/* .
gunzip Tb927_genome.fasta.gz
bowtie2-build Tb927_genome.fasta index 
#before using bowtie, building the index for Tb927_genome.fasta, which is complusory.

while read id stage name1 name2
	do 
	bowtie2 -p 8 --rg-id $id$stage -x index -1 fastq/${name1:0:11} -2 fastq/${name2:0:11} -S out$id$stage.sam 
	#--rg-id to generate a group name, -1and-2 is specific for paired-end sequence, -S output your result as some names
	samtools view -bS out$id$stage.sam > out$id$stage.bam #convert the sam files to the bam files
	done < fastq/fqfiles
git add *.bam
git commit -m "the output of bowtie2 and convert to bam"
zip B180217-2020.Assignment1.zip *.bam

#question4:using bedtools multicov to get the numbers of numbers which align to the regions of the genome that code for genes
for x in out216Slender.bam out218Slender.bam out219Slender.bam out220Stumpy.bam out221Stumpy.bam out222Stumpy.bam 
#before using bedtools multicov, use for loops to make every bam files sorted and indexed, which is complusory
	do
	samtools sort $x -o ${x/./_sort.}
	samtools index ${x/./_sort.}
	done
bedtools multicov -bams out216Slender_sort.bam out218Slender_sort.bam out219Slender_sort.bam out220Stumpy_sort.bam out221Stumpy_sort.bam out222Stumpy_sort.bam -bed Tbbgenes.bed > readscount.txt
git add readscount.txt
git commit -m "question4:the numbers of reads that align to the genome"
zip B180217-2020.Assignment1.zip readscount.txt

#question5: process the output of the question4, to calculate the average counts per genes for each group
echo -e “ \tslender\tstumpy” > average_genes.text
cut -f 4,7,8,9,10,11,12 readscount.txt > readscount_cut.text
while read seq_name slender1 slender2 slender3 stumpy1 stumpy2 stumpy3
	do
	let slender_avg=(slender1+ slender2+ slender3)/3
	let stumpy_avg=(stumpy1+ stumpy2+ stumpy3)/3
	echo -e "${seq_name}\t${slender_avg}\t${stumpy_avg}" >> average_genes.text
	done < readscount_cut.text
git add average_genes.text
git commit -m "the tab-delimited file of average counts of per gene for each group"
zip B180217-2020.Assignment1.zip average_genes.text

